local activated = false

local function getNoclipElement()
	return getPedOccupiedVehicle(localPlayer) or localPlayer
end

local function getPositionFromElementOffset(element, offX, offY, offZ)
	local m = getElementMatrix(element)
	local x = offX * m[1][1] + offY * m[2][1] + offZ * m[3][1] + m[4][1]
	local y = offX * m[1][2] + offY * m[2][2] + offZ * m[3][2] + m[4][2]
	local z = offX * m[1][3] + offY * m[2][3] + offZ * m[3][3] + m[4][3]
	return x, y, z
end

local function setNoclipControls(state)
	toggleControl("sprint", not state)
	toggleControl("crouch", not state)
	toggleControl("jump", not state)
	toggleControl("fire", not state)
	toggleControl("aim_weapon", not state)
	toggleControl("enter_exit", not state)
	setPedCanBeKnockedOffBike(localPlayer, not state)
end

addEvent("command:noclip", true)
addEventHandler("command:noclip", root, function()
	if source ~= localPlayer then return end
	if isPedDead(localPlayer) then
		return outputChatBox("Noclip Cant Be Activated")
	end

	activated = not activated
	local element = getNoclipElement()

	if not activated then
		setElementFrozen(element, false)
		setElementFrozen(localPlayer, false)
		setNoclipControls(false)
		if isElement(element) and getElementType(element) == "vehicle" then
			setElementVelocity(element, 0, 0, 0)
			setElementAngularVelocity(element, 0, 0, 0)
		end
		outputChatBox("noclip OFF")
	else
		setElementFrozen(element, true)
		setNoclipControls(true)
		if getElementType(element) == "vehicle" then
			setElementVelocity(element, 0, 0, 0)
			setElementAngularVelocity(element, 0, 0, 0)
		end
		outputChatBox("noclip ON")
	end
end)

addEventHandler("onClientPedsProcessed", root, function()
	if not activated then return end

	if isPedDead(localPlayer) then
		activated = false
		local element = getNoclipElement()
		setElementFrozen(element, false)
		setElementFrozen(localPlayer, false)
		setNoclipControls(false)
		outputChatBox("Noclip Has Forced To Off")
		return
	end

	if isChatBoxInputActive() or isConsoleActive() or isMTAWindowActive() then
		return
	end

	local veh = getPedOccupiedVehicle(localPlayer)
	local element = veh or localPlayer
	setElementFrozen(element, true)

	local speeddd, updownspeedd
	if getKeyState("lshift") then
		speeddd = 4
		updownspeedd = 3
	elseif getKeyState("lalt") then
		speeddd = 0.3
		updownspeedd = 0.3
	else
		speeddd = 1
		updownspeedd = 1
	end

	setElementVelocity(localPlayer, 0, 0, 0)
	if veh then
		setElementVelocity(veh, 0, 0, 0)
		setElementAngularVelocity(veh, 0, 0, 0)
	end

	if getKeyState("w") then
		local x, y, z = getPositionFromElementOffset(element, 0, speeddd, 0)
		setElementPosition(element, x, y, z, false)
	end
	if getKeyState("s") then
		local x, y, z = getPositionFromElementOffset(element, 0, -speeddd, 0)
		setElementPosition(element, x, y, z, false)
	end
	if getKeyState("a") then
		local x, y, z = getPositionFromElementOffset(element, -speeddd, 0, 0)
		setElementPosition(element, x, y, z, false)
	end
	if getKeyState("d") then
		local x, y, z = getPositionFromElementOffset(element, speeddd, 0, 0)
		setElementPosition(element, x, y, z, false)
	end
	if getKeyState("space") then
		local x, y, z = getPositionFromElementOffset(element, 0, 0, updownspeedd)
		setElementPosition(element, x, y, z, false)
	end
	if getKeyState("lctrl") then
		local x, y, z = getPositionFromElementOffset(element, 0, 0, -updownspeedd)
		setElementPosition(element, x, y, z, false)
	end

	if veh then
		local r1, r2, r3 = getElementRotation(getCamera())
		setElementRotation(veh, r1, r2, r3)
		if getPedOccupiedVehicle(localPlayer) ~= veh then
			warpPedIntoVehicle(localPlayer, veh, 0)
		end
		setPedCanBeKnockedOffBike(localPlayer, false)
	else
		local r = getPedCameraRotation(localPlayer)
		setElementRotation(localPlayer, 0, 0, r)
	end
end)

addEventHandler("onClientKey", root, function(btn, press)
	if not activated or not press then return end
	if btn == "lshift" or btn == "lctrl" or btn == "space" then
		cancelEvent()
	end
end)

addEventHandler("onClientVehicleEnter", root, function(player)
	if player ~= localPlayer then return end
	if activated or getElementData(localPlayer, "duty_admin") == 1 then
		setPedCanBeKnockedOffBike(localPlayer, false)
	else
		setPedCanBeKnockedOffBike(localPlayer, true)
	end
end)

addEventHandler("onClientElementDataChange", localPlayer, function(key)
	if key == "duty_admin" and activated then
		if getElementData(localPlayer, "duty_admin") ~= 1 then
			activated = false
			local element = getNoclipElement()
			setElementFrozen(element, false)
			setElementFrozen(localPlayer, false)
			setNoclipControls(false)
		end
	end
end)