addCommandHandler("noclip", function(player)
	if not player or not isElement(player) or getElementType(player) ~= "player" then
		return
	end

	if not exports.integration:isPlayerTrialAdmin(player) then
		outputChatBox("Access Denied!", player, 255, 0, 0)
		return
	end

	triggerClientEvent(player, "command:noclip", player)
end)